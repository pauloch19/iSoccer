/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package isoccer;

/**
 *
 * @author paulc
 */
interface PessoaMethods{
    String getTipo();
    void setTipo(String tipo);
    String getNome();
    void setNome(String nome);
    String getEmail();
    void setEmail(String email);
    String getCPF();
    int getSalario();
    void setSalario(int salario);
    String getTelefone();
    void setTelefone(String telefone);
    @Override
    String toString();
}



public class Pessoa implements PessoaMethods{
    protected String nome;
    protected String email;
    protected String cpf;
    protected int salario;
    protected String telefone;
    protected String tipo = "tipo";
    
    public Pessoa(String nome, String email, String cpf, int salario, String telefone)
    {
        this.nome = nome;
        this.email = email;
        this.cpf = cpf;
        this.salario = salario;
        this.telefone = telefone;
    }

    @Override
    public String getTipo() {
        return tipo;
    }

    @Override
    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
    
    @Override
    public String getNome() {
        return nome;
    }

    @Override
    public void setNome(String nome) {
        this.nome = nome;
    }

    @Override
    public String getEmail() {
        return email;
    }

    @Override
    public void setEmail(String email) {
        this.email = email;
    }

    @Override
    public String getCPF() {
        return cpf;
    }

    public void setCPF(String cpf) {
        this.cpf = cpf;
    }

    @Override
    public int getSalario() {
        return salario;
    }

    @Override
    public void setSalario(int salario) {
        this.salario = salario;
    }

    @Override
    public String getTelefone() {
        return telefone;
    }

    @Override
    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }
    
    @Override
    public String toString(){
        return "Nome: "+nome+"\nE-mail: "+email+"\nCPF: "+cpf+"\nTelefone: "+telefone;
    }
    
}
