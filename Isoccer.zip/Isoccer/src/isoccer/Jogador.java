/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package isoccer;

/**
 *
 * @author paulc
 */
interface JogadorMethods{
    String getTipo();
    void setTipo(String tipo);
    String getAptidao();
    void setAptidao(String aptidao);
    @Override
    String toString();
}

public class Jogador extends Pessoa implements JogadorMethods{
 private String tip;
 private String aptidao;

    public Jogador(String nome, String email, String cpf, int salario, String telefone, String tipo, String aptidao)
    {
        super(nome, email, cpf, salario, telefone);
        this.tip = tipo;
        this.aptidao = aptidao;
     
    }
 @Override
    public String getTipo() {
        return tip;
    }

 @Override
    public void setTipo(String tipo) {
        this.tip = tipo;
    }

 @Override
    public String getAptidao() {
        return aptidao;
    }

 @Override
    public void setAptidao(String aptidao) {
        this.aptidao = aptidao;
    }
    
 @Override
    public String toString()
    {
        return super.toString()+"\nPosição: "+tip+"\nAptidão: "+aptidao;
    }
 
}
