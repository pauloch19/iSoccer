/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package isoccer;

/**
 *
 * @author paulc
 */

interface SocioMethods{
    String getEndereco();
    void setEndereco(String endereco);
    String getAssociacao();
    void setAssociacao(String associacao);
    int getContribuicao();
    void setContribuicao(int contribuicao);
    @Override
    String toString();
    
}

public class Socio extends Pessoa implements SocioMethods{
    private String endereco;
    private String associacao;
    private int contribuicao;

    public Socio(String nome, String email, String cpf, int salario, String telefone, String endereco, String associacao, int contribuicao)
    {
        super(nome, email, cpf, salario, telefone);
        this.endereco = endereco;
        this.associacao = associacao;
        this.contribuicao = contribuicao;
    }
    
    @Override
    public String getAssociacao() {
        return associacao;
    }

    @Override
    public void setAssociacao(String associacao) {
        this.associacao = associacao;
    }
    
    
    @Override
    public String getEndereco() {
        return endereco;
    }

    @Override
    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    @Override
    public int getContribuicao() {
        return contribuicao;
    }

    @Override
    public void setContribuicao(int contribuicao) {
        this.contribuicao = contribuicao;
    }
    
    @Override
    public String toString(){
        return super.toString()+"\nEndereço: "+endereco+"\nAssociação: "+associacao+"\nContribuição: "+contribuicao;
    }
    
}
