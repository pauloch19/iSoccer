/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package isoccer;

/**
 *
 * @author paulc
 */
interface MotoristaMethods{
    String getHabilitacao();
    void setHabilitacao(String habilitacao);
    @Override
    String toString();
    
}

public class Motorista extends Pessoa implements MotoristaMethods{
    private String habilitacao;

    public Motorista(String nome, String email, String cpf, int salario, String telefone, String habilitacao)
    {
        super(nome, email, cpf, salario, telefone);
        this.habilitacao = habilitacao;
    }
    
    @Override
    public String getHabilitacao() {
        return habilitacao;
    }

    @Override
    public void setHabilitacao(String habilitacao) {
        this.habilitacao = habilitacao;
    }
    
    @Override
    public String toString(){
        return super.toString()+"\nHabilitação: "+habilitacao;
    }
    
}
