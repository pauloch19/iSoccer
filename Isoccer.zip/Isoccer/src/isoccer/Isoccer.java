/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package isoccer;
import java.util.Scanner;
/**
 *
 * @author paulc
 */
public class Isoccer {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String login = "admin";
        String senha = "admin";
        String loginDado, senhaDada;
        int opcao=0, contribuicao=0;
        int contribuicaoJ=0, contribuicaoS=0, contribuicaoE=0;
        boolean entrada = false;
        Time time = new Time();
        System.out.println("Bem-vindo ao iSoccer.");
        System.out.println("Como por padrão o login é admin e a senha é admin");
        System.out.print("Para parar o programa digite nao ou digite sim para rodar o programa.");
        System.out.print("Deseja acessar o sistema: ");
        String escolha = scanner.nextLine();
    while(!escolha.equals("nao"))
    {
        if(escolha.equals("sim"))
        {
            while(!entrada)
            {
                System.out.print("Digite o login: ");
                loginDado = scanner.nextLine();
                System.out.print("Digite a senha: ");
                senhaDada = scanner.nextLine();
                if(loginDado.equals(login) && senhaDada.equals(senha))
                {
                    entrada=true;
                    System.out.println("Login realizado com sucesso!");
                }
            }
            entrada = false;
            System.out.println("1.Adicinoar Funcionário\n2.Adicionar Recurso\n3.Adicionar Sócio\n4.Alterar dados do sistema\n5.Fazer Relatórios\n6.Sair");
            while(!entrada)
            {
                try{
                System.out.println("Escolha uma das opções acima: ");
                opcao = Integer.parseInt(scanner.next());
                entrada = true;
                }
                catch(NumberFormatException e){
                    System.out.println("A entrada esperada é um valor numérico.");
                }
            }
            entrada = false;
            scanner.nextLine();
        while(opcao!=6)
        {
            
            if(opcao==1)
            {
                System.out.println("Você entrou na opção adicionar funcionário.");
                System.out.print("Qual o tipo do funcionário: ");
                String tipo = scanner.nextLine();
                Info(tipo, time);
            }
            if(opcao==2)
            {
                System.out.println("Você entrou na opção adicionar recurso");
                System.out.print("Adicionarn\nRemover\nVerificar\n");
                System.out.print("Digite uma das opções acima: ");
                escolha = scanner.nextLine();
                if(escolha.equals("adicionar"))
                {
                    System.out.print("Qual o tipo do recurso: ");
                    String tipo =scanner.nextLine();
                    RecursoInfo(tipo, time);
                }
                if(escolha.equals("remover"))
                {
                   System.out.print("Qual o tipo do recurso: ");
                   String tipo =scanner.nextLine();
                   time.RemoverRecurso(tipo);
                }
                if(escolha.equals("verificar"))
                {
                    System.out.print("Qual o tipo do recurso: ");
                    String tipo =scanner.nextLine();
                    time.Verificacao(tipo);
                }
            }
            if(opcao==3)
            {
                System.out.println("Você entrou na opção de Sócio");
                System.out.print("Deseja adicionar um sócio-torcedor: ");
                escolha = scanner.nextLine();
                if(escolha.equals("sim"))
                {
                    System.out.print("Nome do torcedor: ");
                    String nome = scanner.nextLine();
                    System.out.println("Os tipos são: junior, senior, elite");
                    System.out.print("Tipo de sócio: ");
                    String tipo = scanner.nextLine();
                    System.out.print("E-mail: ");
                    String email = scanner.nextLine();
                    System.out.print("CPF: ");
                    String cpf = scanner.nextLine();
                    System.out.print("Telefone: ");
                    String telefone = scanner.nextLine();
                    System.out.print("Endereço: ");
                    String endereco = scanner.nextLine();       
                    while(!entrada)
                    {
                        try{
                            System.out.print("Valor da contribuição: ");
                            contribuicao = Integer.parseInt(scanner.next());
                            entrada = true;
                        }
                        catch(NumberFormatException e){
                            System.out.println("A entrada esperada é um valor numérico.");
                        }
                    }
                    entrada=false;
                    Pessoa socio = new Socio(nome, email, cpf, 0, telefone, endereco, tipo, contribuicao);
                    socio.setTipo("socio");
                    time.AddSocio(socio);
                }
            }
            if(opcao==4)
            {
                System.out.println("Você entrou na opção alterar dados do sistema.");
                System.out.print("Deseja alterar o login e a senha: ");
                escolha = scanner.nextLine();
                if(escolha.equals("sim"))
                {
                   System.out.print("Novo login: ");
                   login = scanner.nextLine();
                   System.out.print("Nova senha: ");
                   senha = scanner.nextLine();
                   System.out.println("Senha e login alterados com sucesso, você voltará para o menu principal para fazer login novamente.");
                   break;
                }   
                System.out.print("Deseja alterar os valor de contribuição do sócio-torcedor júnior: ");
                escolha = scanner.nextLine();
                if(escolha.equals("sim"))
                {
                    while(!entrada)
                    {
                        try{
                            System.out.print("Novo valor: ");
                            contribuicaoJ = Integer.parseInt(scanner.next());
                            entrada = true;
                        }
                        catch(NumberFormatException e){
                        System.out.println("A entrada esperada é um valor numérico.");
                        }
                    }
                    entrada=false;
                    scanner.nextLine();
                }
                System.out.print("Deseja alterar os valor de contribuição do sócio-torcedor sênior: ");
                escolha = scanner.nextLine();
               if(escolha.equals("sim"))
                {
                    while(!entrada)
                    {
                        try{
                            System.out.print("Novo valor: ");
                            contribuicaoS = Integer.parseInt(scanner.next());
                            entrada = true;
                        }
                        catch(NumberFormatException e){
                        System.out.println("A entrada esperada é um valor numérico.");
                        }
                    }
                    entrada=false;
                    scanner.nextLine();
                }
                System.out.print("Deseja alterar os valor de contribuição do sócio-torcedor elite: ");
                escolha = scanner.nextLine();
                if(escolha.equals("sim"))
                {
                    while(!entrada)
                    {
                        try{
                            System.out.print("Novo valor: ");
                            contribuicaoE = Integer.parseInt(scanner.next());
                            entrada = true;
                        }
                        catch(NumberFormatException e){
                        System.out.println("A entrada esperada é um valor numérico.");
                        }
                    }
                    scanner.nextLine();
                }
            }
            if(opcao==5)
            {
                System.out.println("Você entrou na opção fazer relatórios.");
                System.out.println("Fazer relatório sobre:\n1.Funcionários\n2.Recursos\n3.Sócios");
                System.out.print("Qual das opções acima: ");
                opcao = scanner.nextInt();
                scanner.nextLine();
                if(opcao==1)
                {
                    time.RodarRelatorio();
                    time.EstadoJogadores();
                    time.ServicosGerais();
                }
                if(opcao==2)
                {
                    time.MostrarRecursos();
                }
                if(opcao==3)
                {
                    System.out.println("Quantidade de sócios: "+time.listaSocios.size());
                    time.VerificarSocios(contribuicaoJ, contribuicaoE, contribuicaoS);
                }
                
            }
            System.out.println("1.Adicinoar Funcionário\n2.Adicionar Recurso\n3.Adicionar Sócio\n4.Alterar dados do sistema\n5.Fazer Relatórios\n6.Sair");
            opcao=0;
            entrada=false;
            while(!entrada)
            {
                try{
                System.out.println("Escolha uma das opções acima: ");
                opcao = Integer.parseInt(scanner.next());
                entrada = true;
                }
                catch(NumberFormatException e){
                    System.out.println("A entrada esperada é um valor numérico.");
                }
            }
            entrada = false;
            scanner.nextLine();
        }    
        }
        System.out.print("Deseja acessar o sistema: ");
        escolha = scanner.nextLine();
    }
        
        
    }
    
    public static void RecursoInfo(String tipo, Time time)
    {
        boolean entrada = false;
        Scanner scanner = new Scanner(System.in);
        int torcedores=0, lanchonetes=0, banheiros=0, dormitorios=0;
        System.out.println("Indique se o "+tipo+" está disponivel ou indisponivel.");
        System.out.print("Disponibilidade: ");
        String disponibilidade = scanner.nextLine();
        if(tipo.equals("estadio"))
        {
            while(!entrada)
            {
                try{
                System.out.print("Capacidade de torcedores: ");
                torcedores = Integer.parseInt(scanner.next());
                entrada = true;
                }
                catch(NumberFormatException e){
                    System.out.println("A entrada esperada é um valor numérico.");
                }
            }
            entrada=false;
            while(!entrada)
            {
                try{
                System.out.print("Quantidade de banheiros: ");
                banheiros = Integer.parseInt(scanner.next());
                entrada = true;
                }
                catch(NumberFormatException e){
                    System.out.println("A entrada esperada é um valor numérico.");
                }
            }
            entrada=false;
            while(!entrada)
            {
                try{
                System.out.print("Quantidade de lanchonetes: ");
                lanchonetes = Integer.parseInt(scanner.next());
                entrada = true;
                }
                catch(NumberFormatException e){
                    System.out.println("A entrada esperada é um valor numérico.");
                }
            }
            entrada=false;
            Recurso recurso = new Estadio(torcedores, banheiros, lanchonetes, disponibilidade);
            time.AddRecurso(recurso);
        }
        else if(tipo.equals("centro"))
        {
           while(!entrada)
            {
                try{
                System.out.print("Quantidade de Dormitórios: ");
                dormitorios = Integer.parseInt(scanner.next());
                entrada = true;
                }
                catch(NumberFormatException e){
                    System.out.println("A entrada esperada é um valor numérico.");
                }
            } 
            Recurso recurso = new Centro(dormitorios, disponibilidade);
            time.AddRecurso(recurso);
        }
        else
        {
            Recurso recurso = new Recurso(disponibilidade);
            recurso.setTipo(tipo);
            time.AddRecurso(recurso);
        }
    }
    
    public static void Info(String tipo, Time time)
    {
        Scanner scanner = new Scanner(System.in);
        boolean entrada=false;
        int salario=0;
        System.out.print("Qual o nome do "+tipo+": ");
        String nome = scanner.nextLine();
        System.out.print("E-mail: ");
        String email = scanner.nextLine();
        System.out.print("CPF: ");
        String cpf = scanner.nextLine();
        while(!entrada)
        {
                try{
                System.out.print("Salário: ");
                salario = Integer.parseInt(scanner.next());
                entrada = true;
                }
                catch(NumberFormatException e){
                    System.out.println("A entrada esperada é um valor numérico.");
                }
        }
        scanner.nextLine();
        System.out.print("Telefone: ");
        String telefone = scanner.nextLine();
        if(tipo.equals("jogador"))
        {
            System.out.print("posição: ");
            String posicao = scanner.nextLine();
            System.out.print("O jogador está apto a jogar: ");
            String aptidao = scanner.nextLine();
            if(aptidao.equals("sim"))
            {
                aptidao = "apto";
            }
            else
            {
                aptidao = "inapto";
            }
            Pessoa pessoa = new Jogador(nome, email, cpf, salario, telefone, posicao, aptidao);
            time.jogadores.add(pessoa);
        }
        else if(tipo.equals("motorista"))
        {
            System.out.print("Digite o número da habilitação: ");
            String habilitacao = scanner.nextLine();
            Pessoa pessoa = new Motorista(nome, email, cpf, salario, telefone, habilitacao);
            time.AddFuncionario(pessoa);
        }
        else if(tipo.equals("medico"))
        {
            System.out.print("Digite o CRM: ");
            String crm = scanner.nextLine();
            Pessoa pessoa = new Medico(nome, email, cpf, salario, telefone, crm);
            time.AddFuncionario(pessoa);
        }
        else
        {
            Pessoa pessoa = new Pessoa(nome, email, cpf, salario, telefone);
            pessoa.setTipo(tipo);
            time.AddFuncionario(pessoa);
        }
    }
    
}
