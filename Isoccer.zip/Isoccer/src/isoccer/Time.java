/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package isoccer;


/**
 *
 * @author paulc
 */
interface TimeMethods{
    void AddFuncionario(Pessoa pessoa);
    void AddRecurso(Recurso recurso);
    void VerificarSocios(int junior, int elite, int senior);
    void AddSocio(Pessoa pessoa);
    void RodarRelatorio();
    void EstadoJogadores();
    void ServicosGerais();
    void MostrarRecursos();
    void RemoverRecurso(String tipo);
    void Verificacao(String tipo);
    
}

public class Time implements TimeMethods{
    java.util.ArrayList<Pessoa> listaPessoas = new java.util.ArrayList<>();
    java.util.ArrayList<Recurso> listaRecursos = new java.util.ArrayList<>();
    java.util.ArrayList<Pessoa> listaSocios = new java.util.ArrayList<>();
    java.util.ArrayList<Pessoa> jogadores= new java.util.ArrayList<>();
    
    
    @Override
    public void AddFuncionario(Pessoa pessoa)
    {
        listaPessoas.add(pessoa);
        System.out.println("Adicionado com sucesso ao time!");
    }
    
    @Override
    public void AddRecurso(Recurso recurso)
    {
        listaRecursos.add(recurso);
        System.out.println("Adicionado com sucesso ao time!");
    }
    
    @Override
    public void VerificarSocios(int junior, int elite, int senior)
    {
        int i, adimplente=0, inadimplente=0;
        Pessoa pessoa;
        for(i=0;i<listaSocios.size();i++)
        {
            pessoa = listaSocios.get(i);
            if(((Socio) pessoa).getAssociacao().equals("junior"))
            {
                if(((Socio) pessoa).getContribuicao()>=junior)
                {
                    adimplente++;
                }
                else
                {
                    inadimplente++;
                }
            }
            if(((Socio) pessoa).getAssociacao().equals("senior"))
            {
                if(((Socio) pessoa).getContribuicao()>=senior)
                {
                    adimplente++;
                }
                else
                {
                    inadimplente++;
                }
            }
            if(((Socio) pessoa).getAssociacao().equals("elite"))
            {
                if(((Socio) pessoa).getContribuicao()>=elite)
                {
                    adimplente++;
                }
                else
                {
                    inadimplente++;
                }
            } 
        }
        System.out.println("Quantidade de sócios adimplentes: "+adimplente+"\nQuantidade de sócios inadimplentes: "+inadimplente);
        System.out.println("###############################################################################################################");
        System.out.println("Sócios: ");
        for(i=0;i<listaSocios.size();i++)
        {
            pessoa = listaSocios.get(i);
            System.out.println(pessoa.toString());
            System.out.println("###########################################");
        }
    }
    
    @Override
    public void AddSocio(Pessoa pessoa)
    {
        listaSocios.add(pessoa);
        System.out.println("Sócio torcedor adicionado com sucesso!");
    }
    
    @Override
    public void RodarRelatorio()
    {
       
        int i;
        Pessoa pessoa;
        System.out.println("Técnico: ");
        for(i=0;i<listaPessoas.size();i++)
        {
            pessoa = listaPessoas.get(i);
            if(pessoa.getTipo().equals("tecnico"))
            {
               System.out.println(pessoa.toString()+"\nSalário: "+pessoa.getSalario());
               System.out.println("#########################################################");
               break;
            }
        }
        System.out.println("Jogadores: ");
        for(i=0;i<jogadores.size();i++)
        {
            pessoa = jogadores.get(i);
            System.out.println(pessoa.toString()+"\nSalário: "+pessoa.getSalario());
            System.out.println("#########################################################");
        }      
    }
    
    @Override
    public void EstadoJogadores()
    {    
        int i;
        Pessoa pessoa;
        System.out.println("Jogadores Aptos: ");
        for(i=0;i<jogadores.size();i++)
        {
            pessoa = jogadores.get(i);
            if(((Jogador) pessoa).getAptidao().equals("apto"))
            {
                System.out.println(pessoa.toString()+"\nSalário: "+pessoa.getSalario());
                System.out.println("#########################################################");
            }  
        } 
        System.out.println("Jogadores Inaptos: ");
        for(i=0;i<jogadores.size();i++)
        {
            pessoa = jogadores.get(i);
            if(((Jogador) pessoa).getAptidao().equals("inapto"))
            {
                System.out.println(pessoa.toString()+"\nSalário: "+pessoa.getSalario());
                System.out.println("#########################################################");
            }  
        } 
    }
    
    @Override
    public void ServicosGerais()
    {
        int i;
        Pessoa pessoa;
        System.out.println("Serviços Gerais: ");
        for(i=0;i<listaPessoas.size();i++)
        {
            pessoa = listaPessoas.get(i);
            if(!pessoa.getTipo().equals("tecnico"))
            {
                System.out.println(pessoa.toString()+"\nSalário: "+pessoa.getSalario());
                System.out.println("#########################################################");
            }       
        }
        
    }
    
    @Override
    public void MostrarRecursos()
    {
        int i;
        Recurso recurso;
        System.out.println("Recursos: ");
        for(i=0;i<listaRecursos.size();i++)
        {
            recurso = listaRecursos.get(i);
            if(!(recurso instanceof Estadio) && !(recurso instanceof Centro))
            {
                System.out.println(recurso.getTipo()+": "+recurso.toString());
                System.out.println("#########################################################");
            }   
        }
        for(i=0;i<listaRecursos.size();i++)
        {
            recurso = listaRecursos.get(i);
            if(recurso instanceof Estadio)
            {
                System.out.println("Estádio: "+recurso.toString());
                System.out.println("#########################################################");
            }   
        }
        for(i=0;i<listaRecursos.size();i++)
        {
            recurso = listaRecursos.get(i);
            if(recurso instanceof Centro)
            {
                System.out.println("Centro de treinamento: "+recurso.toString());
                System.out.println("#########################################################");
            }   
        }
        
    }
    
    @Override
    public void RemoverRecurso(String tipo)
    {
        int i;
        Recurso recurso;
        for(i=0;i<listaRecursos.size();i++)
        {
            recurso = listaRecursos.get(i);
            if(recurso.getTipo().equals(tipo))
            {
                listaRecursos.remove(listaRecursos.get(i));
                System.out.println("Um ônibus foi removido da lista de recursos do time");
                break;
            }
            else if(tipo.equals("estadio"))
            {
                if(recurso instanceof Estadio)
                {
                    listaRecursos.remove(listaRecursos.get(i));
                    System.out.println("Um estádio foi removido da lista de recursos do time");
                    break;
                }
            }
            else if(tipo.equals("centro"))
            {
                if(recurso instanceof Centro)
                {
                    listaRecursos.remove(listaRecursos.get(i));
                    System.out.println("Um centro de treinamento foi removido da lista de recursos do time");
                    break;
                } 
            }
        }
    }
    
    @Override
    public void Verificacao(String tipo)
    {
        int i, qtdD=0, qtdIn=0;
        Recurso recurso;
        
        for(i=0;i<listaRecursos.size();i++)
        {
            recurso = listaRecursos.get(i);
            if(recurso.getTipo().equals(tipo))
            {
               if(recurso.getDisponibilidade().equals("disponivel"))
               {
                   qtdD++;
               }
               else
               {
                   qtdIn++;
               }
            }
            else if(tipo.equals("estadio"))
            {
                if(recurso instanceof Estadio)
                {
                    if(recurso.getDisponibilidade().equals("disponivel"))
                    {
                        qtdD++;
                    }
                    else
                    {
                        qtdIn++;
                    }
                }
            }
            else if(tipo.equals("centro"))
            {
                if(recurso instanceof Centro)
                {
                    if(recurso.getDisponibilidade().equals("disponivel"))
                    {
                        qtdD++;
                    }
                    else
                    {
                        qtdIn++;
                    }
                } 
            }
        }
        System.out.println("Quantidade de "+tipo+" Disponíveis: "+qtdD);
        System.out.println("Quantidade de "+tipo+" Indisponíveis: "+qtdIn);
    }
}
