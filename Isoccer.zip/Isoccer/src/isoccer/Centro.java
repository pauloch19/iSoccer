/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package isoccer;

/**
 *
 * @author paulc
 */
interface CentroMethods{
    int getDormitorios();
    void setDormitorios(int dormitorios);
    @Override
    String toString();
    
}


public class Centro extends Recurso implements CentroMethods{
    private int dormitorios;

    @Override
    public int getDormitorios() {
        return dormitorios;
    }

    @Override
    public void setDormitorios(int dormitorios) {
        this.dormitorios = dormitorios;
    }
    
    public Centro(int dormitorios, String disponibilidade)
    {
        super(disponibilidade);
        this.dormitorios = dormitorios;
    }
    
    @Override
    public String toString(){
        return super.toString()+"Dormitórios: "+dormitorios;
    }
}
