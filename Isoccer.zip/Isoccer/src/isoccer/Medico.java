/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package isoccer;

/**
 *
 * @author paulc
 */
interface MedicoMethods{
    String getCrm();
    void setCrm(String crm);
    @Override
    String toString();
}

public class Medico extends Pessoa implements MedicoMethods{
    private String crm;
    public Medico(String nome, String email, String cpf, int salario, String telefone, String crm)
    {
        super(nome, email, cpf, salario, telefone);
        this.crm = crm; 
    }

    @Override
    public String getCrm() {
        return crm;
    }

    @Override
    public void setCrm(String crm) {
        this.crm = crm;
    }
    
    @Override
    public String toString(){
        return super.toString()+ "\nCRM: "+crm;
    }
}
