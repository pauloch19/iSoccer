/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package isoccer;

/**
 *
 * @author paulc
 */
interface RecursoMethods{
    String getTipo();
    void setTipo(String tipo);
    String getDisponibilidade();
    void setDisponibilidade(String disponibilidade);
    @Override
    String toString();
            
    
}


public class Recurso implements RecursoMethods{
    protected String disponibilidade;
    private String tipo;
    
    public Recurso(String disponibilidade)
    {
        this.disponibilidade = disponibilidade;
    }

    @Override
    public String getTipo() {
        return tipo;
    }

    @Override
    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
    
    
    @Override
    public String getDisponibilidade() {
        return disponibilidade;
    }

    @Override
    public void setDisponibilidade(String disponibilidade) {
        this.disponibilidade = disponibilidade;
    }
    
    @Override
    public String toString(){
        return "Disponibilidade: "+disponibilidade;
    }
    
}
