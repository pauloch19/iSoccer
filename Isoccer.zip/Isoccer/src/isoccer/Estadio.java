/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package isoccer;

/**
 *
 * @author paulc
 */

interface EstadioMethods{
    int getCapacidade();
    void setCapacidade(int capacidade);
    int getBanheiros();
    void setBanheiros(int banheiros);
    int getLanchonetes();
    void setLanchonetes(int lanchonetes);
    @Override
    String toString();
}


public class Estadio extends Recurso implements EstadioMethods{
   private int capacidade;
   private int banheiros;
   private int lanchonetes;
   
    public Estadio(int capacidade, int banheiros, int lanchonetes, String disponibilidade)
    {
        super(disponibilidade);
        this.capacidade = capacidade;
        this.banheiros = banheiros;
        this.lanchonetes = lanchonetes;
    }

   @Override
    public int getLanchonetes() {
        return lanchonetes;
    }

   @Override
    public void setLanchonetes(int lanchonetes) {
        this.lanchonetes = lanchonetes;
    }
    

   @Override
    public int getCapacidade() {
        return capacidade;
    }

   @Override
    public void setCapacidade(int capacidade) {
        this.capacidade = capacidade;
    }

   @Override
    public int getBanheiros() {
        return banheiros;
    }

   @Override
    public void setBanheiros(int banheiros) {
        this.banheiros = banheiros;
    }
   
   @Override
    public String toString(){
        return super.toString()+"\nCapacidade: "+capacidade+"\nBanheiros: "+banheiros+"\nLanchonetes: "+lanchonetes;
    }
    
}
